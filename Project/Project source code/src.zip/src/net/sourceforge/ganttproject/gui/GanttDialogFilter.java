package net.sourceforge.ganttproject.gui;

import net.sourceforge.ganttproject.GPLogger;
import net.sourceforge.ganttproject.GanttTask;
import net.sourceforge.ganttproject.IGanttProject;
import net.sourceforge.ganttproject.action.CancelAction;
import net.sourceforge.ganttproject.action.OkAction;
import net.sourceforge.ganttproject.language.GanttLanguage;
import net.sourceforge.ganttproject.task.dependency.TaskDependencyException;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.text.MessageFormat;

public class GanttDialogFilter {

    private final GanttTask[] allTasks;
    public GanttDialogFilter(GanttTask[] tasks){
        allTasks = tasks;
    }

    public void show(final IGanttProject project, final UIFacade uiFacade){
        final GanttTaskFilterBean taskFilterBean = new GanttTaskFilterBean(allTasks, project, uiFacade);
        final Action[] actions = new Action[]{new OkAction() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                uiFacade.getUndoManager().undoableEdit("Active Filter", new Runnable() {
                    @Override
                    public void run() {
                        taskFilterBean.applySettings();
                        uiFacade.refresh();
                    }
                });
            }
        }, CancelAction.EMPTY};

        final String title = "Filter";
        uiFacade.createDialog(taskFilterBean, actions, title).show();
    }
}
