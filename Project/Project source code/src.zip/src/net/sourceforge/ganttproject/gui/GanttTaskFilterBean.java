/*
GanttProject is an opensource project management tool.
Copyright (C) 2011 GanttProject team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package net.sourceforge.ganttproject.gui;

import biz.ganttproject.core.option.ColorOption;
import biz.ganttproject.core.option.DefaultColorOption;
import biz.ganttproject.core.time.*;
import biz.ganttproject.core.time.impl.*;
import net.sourceforge.ganttproject.*;
import net.sourceforge.ganttproject.gui.options.OptionsPageBuilder;
import net.sourceforge.ganttproject.gui.options.SpringUtilities;
import net.sourceforge.ganttproject.task.*;

import javax.swing.*;
import java.awt.*;
import org.jdesktop.swingx.JXHyperlink;

/**
 * Real panel for editing task properties
 */
public class GanttTaskFilterBean extends JPanel {

    enum FilterType {

        DURATION(0), PROGRESS(1), BEGIN_DATE(0), END_DATE(1);

        private final int index;

        private FilterType(int index) {
            this.index = index;
        }

        public int index() {
            return index;
        }

    }

    private ColorOption myTaskColorOption = new DefaultColorOption("");

    private GanttTask[] selectedTasks;

    private JTabbedPane tabbedPane; // TabbedPane that includes the following four
    // items
    private JPanel filterPanel;

    private JPanel filterPanel2;

    private JTextField attributeValueField;

    private JTextField dayField;

    private JTextField monthField;

    private JTextField yearField;

    private JComboBox filterComboBox;

    private JComboBox filterDateComboBox;

    private final UIFacade myUIfacade;

    public GanttTaskFilterBean(GanttTask[] selectedTasks, IGanttProject project, UIFacade uifacade) {
        this.selectedTasks = selectedTasks;
        myUIfacade = uifacade;
        init();
    }

    private static void addEmptyRow(JPanel form) {
        form.add(Box.createRigidArea(new Dimension(1, 10)));
        form.add(Box.createRigidArea(new Dimension(1, 10)));
    }

    /**
     * Construct the general panel
     */
    private void constructGeneralPanel() {
        final JPanel generalPanel = new JPanel(new SpringLayout());

        generalPanel.add(new JLabel("Filters: "));
        filterComboBox = new JComboBox();

        String[] filters = {"Duration", "Progress"};
        for (String attrib : filters) {
            filterComboBox.addItem(attrib);
        }
        filterComboBox.setEditable(false);
        generalPanel.add(filterComboBox);

        addEmptyRow(generalPanel);

        generalPanel.add(new JLabel("Value: "));
        attributeValueField = new JTextField(20);
        generalPanel.add(attributeValueField);

        addEmptyRow(generalPanel);

        OptionsPageBuilder builder = new OptionsPageBuilder(GanttTaskFilterBean.this, OptionsPageBuilder.TWO_COLUMN_LAYOUT);
        builder.setUiFacade(myUIfacade);
        JPanel colorBox = new JPanel(new BorderLayout(5, 0));
        colorBox.add(builder.createColorComponent(myTaskColorOption).getJComponent(), BorderLayout.WEST);

        generalPanel.add(new JLabel("Filter color "));
        generalPanel.add(colorBox);

        SpringUtilities.makeCompactGrid(generalPanel, generalPanel.getComponentCount() / 2, 2, 1, 1, 5, 5);

        JPanel filterWrapper = new JPanel(new BorderLayout());
        filterWrapper.add(generalPanel, BorderLayout.NORTH);
        filterPanel = new JPanel(new BorderLayout());
        filterPanel.add(filterWrapper);
    }

    private void constructDatePanel() {
        final JPanel datePanel = new JPanel(new BorderLayout(0, 10));

        filterDateComboBox = new JComboBox();

        String[] filters = {"Begin date", "End date"};
        for (String attrib : filters) {
            filterDateComboBox.addItem(attrib);
        }
        filterDateComboBox.setEditable(false);
        datePanel.add(filterDateComboBox, BorderLayout.NORTH);

        addEmptyRow(datePanel);

        Box dateBox = Box.createHorizontalBox();
        dateBox.add(new JLabel("Day:  "));
        dayField = new JTextField();
        dayField.setPreferredSize(new Dimension(20,20));
        dateBox.add(dayField);
        dateBox.add(Box.createHorizontalStrut(15));

        dateBox.add(new JLabel("Month:  "));
        monthField = new JTextField();
        monthField.setPreferredSize(new Dimension(20,20));
        dateBox.add(monthField);
        dateBox.add(Box.createHorizontalStrut(15));

        dateBox.add(new JLabel("Year:  "));
        yearField = new JTextField();
        yearField.setPreferredSize(new Dimension(20,20));
        dateBox.add(yearField);

        addEmptyRow(datePanel);

        datePanel.add(dateBox, BorderLayout.CENTER);


        Box cBox = Box.createHorizontalBox();
        OptionsPageBuilder builder = new OptionsPageBuilder(GanttTaskFilterBean.this, OptionsPageBuilder.TWO_COLUMN_LAYOUT);
        builder.setUiFacade(myUIfacade);
        JPanel colorBox = new JPanel(new BorderLayout(5, 0));
        colorBox.add(builder.createColorComponent(myTaskColorOption).getJComponent(), BorderLayout.WEST);


        cBox.add(new JLabel("Filter color "));
        cBox.add(colorBox);
        datePanel.add(cBox, BorderLayout.SOUTH);

        SpringUtilities.makeCompactGrid(datePanel, datePanel.getComponentCount() / 2, 2, 1, 1, 5, 5);

        JPanel filterWrapper = new JPanel(new BorderLayout());
        filterWrapper.add(datePanel, BorderLayout.NORTH);
        filterPanel2 = new JPanel(new BorderLayout());
        filterPanel2.add(filterWrapper);
    }

    /**
     * Initialize the widgets
     */
    private void init() {

        tabbedPane = new JTabbedPane() {
            @Override
            public void addTab(String title, Icon icon, Component component) {
                super.addTab(title, icon, UIUtil.contentPaneBorder((JComponent) component));
            }
        };
        constructGeneralPanel();

        tabbedPane.addTab("General", new ImageIcon(getClass().getResource("/icons/properties_16.gif")),
                filterPanel);

        constructDatePanel();

        tabbedPane.addTab("Date", new ImageIcon(getClass().getResource("/icons/properties_16.gif")),
                filterPanel2);

        setLayout(new BorderLayout());

        add(tabbedPane, BorderLayout.CENTER);

        tabbedPane.setBorder(BorderFactory.createEmptyBorder(2, 0, 5, 0));
    }

    /**
     * Apply the modified properties to the selected Tasks
     */
    public void applySettings() {
        int tabIndex = tabbedPane.getSelectedIndex();
        if(tabIndex == 0)
            taskGeneralFilter(filterComboBox.getSelectedIndex());
        else if(tabIndex == 1)
            taskDateFilter(filterDateComboBox.getSelectedIndex());
        else
            System.err.println("Invalid tab selected.");
    }

    private void filterByDuration() {
        int duration = Integer.parseInt(attributeValueField.getText());
        TimeDuration tDuration = new TimeDurationImpl(GPTimeUnitStack.DAY, (long) duration);
        for (GanttTask gTask : selectedTasks) {
            TaskMutator mutator = gTask.createMutator();
            if (gTask.getDuration().equals(tDuration))
                mutator.setColor(myTaskColorOption.getValue());
            mutator.commit();
        }
    }

    private void filterByCompletion() {
        int completionPercentage = Integer.parseInt(attributeValueField.getText());
        for (GanttTask gTask : selectedTasks) {
            TaskMutator mutator = gTask.createMutator();
            if (gTask.getCompletionPercentage() == completionPercentage)
                mutator.setColor(myTaskColorOption.getValue());
            mutator.commit();
        }
    }

    private void filterByStartDate() {
        GanttCalendar insertedStart = CalendarFactory.createGanttCalendar(getYear(), getMonth(), getDay());
        for (GanttTask gTask : selectedTasks) {
            TaskMutator mutator = gTask.createMutator();
            if (insertedStart.equals(gTask.getStart()))
                mutator.setColor(myTaskColorOption.getValue());
            mutator.commit();
        }
    }

    private void filterByEndDate() {
        GanttCalendar insertedEnd = CalendarFactory.createGanttCalendar(getYear(), getMonth(), getDay());
        for (GanttTask gTask : selectedTasks) {
            TaskMutator mutator = gTask.createMutator();
            if (insertedEnd.equals(gTask.getEnd()))
                mutator.setColor(myTaskColorOption.getValue());
            mutator.commit();
        }
    }

    private void taskGeneralFilter(int sIndex) {
        if(sIndex == FilterType.DURATION.index())
            filterByDuration();
        else filterByCompletion();
    }

    private void taskDateFilter(int sIndex) {
        if(sIndex == FilterType.BEGIN_DATE.index())
            filterByStartDate();
        else filterByEndDate();
    }

    private int getDay(){
        return Integer.parseInt(dayField.getText());
    }

    private int getMonth(){
        return Integer.parseInt(monthField.getText()) - 1;
    }

    private int getYear(){
        return Integer.parseInt(yearField.getText());
    }
}