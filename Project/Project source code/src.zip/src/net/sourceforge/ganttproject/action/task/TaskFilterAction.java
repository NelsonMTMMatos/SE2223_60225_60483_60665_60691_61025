package net.sourceforge.ganttproject.action.task;

import net.sourceforge.ganttproject.GanttTask;
import net.sourceforge.ganttproject.GanttTree2;
import net.sourceforge.ganttproject.IGanttProject;
import net.sourceforge.ganttproject.action.GPAction;
import net.sourceforge.ganttproject.gui.GanttDialogFilter;
import net.sourceforge.ganttproject.gui.GanttDialogProperties;
import net.sourceforge.ganttproject.gui.UIFacade;
import net.sourceforge.ganttproject.task.Task;
import net.sourceforge.ganttproject.task.TaskManager;
import net.sourceforge.ganttproject.task.TaskSelectionManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class TaskFilterAction extends TaskActionBase {

    private final IGanttProject myProject;

    public TaskFilterAction(IGanttProject project, TaskSelectionManager selectionManager, UIFacade uiFacade) {
        super("Filter", project.getTaskManager(), selectionManager, uiFacade, null, IconSize.MENU);
        myProject = project;
    }

    @Override
    protected boolean isEnabled(List<Task> selection) {
        return selection.size() != 0;
    }

    @Override
    protected void run(List<Task> selection) throws Exception {
        if (selection.size() == 0) {
            return;
        }

        final GanttTask[] tasks = new GanttTask[selection.size()];
        for(int i = 0; i < selection.size(); i++)
            tasks[i] = (GanttTask) selection.get(i);
        GanttDialogFilter pd = new GanttDialogFilter(tasks);
        getSelectionManager().setUserInputConsumer(pd);
        pd.show(myProject, getUIFacade());

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                getSelectionManager().clear();
            }
        });
    }
}